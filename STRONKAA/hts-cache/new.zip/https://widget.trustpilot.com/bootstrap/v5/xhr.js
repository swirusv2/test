<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trustpilot Custom Widget</title>
    <style type="text/css">
        html, body {
            padding: 0;
            margin: 0;
            height: 100%;
            width: 100%;
            display: block;
        }

        body {
            /* Internet Explorer 10 */
            display: -ms-flexbox;
            -ms-flex-pack: center;
            -ms-flex-align: center;
            /* Firefox */
            display: -moz-box;
            -moz-box-pack: center;
            -moz-box-align: center;
            /* Safari, Opera, and Chrome */
            display: -webkit-box;
            -webkit-box-pack: center;
            -webkit-box-align: center;
            /* W3C */
            display: box;
            box-pack: center;
            box-align: center;
        }

        img {
          height: 100%;
          max-height: 38px;
        }
    </style>
</head>
<body>
    <img src="//images-static.trustpilot.com/api/logos/light-bg/logo.svg" width="255" alt="Trustpilot Custom Widget" />
</body>
</html>
